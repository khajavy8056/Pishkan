import { useEffect, useRef } from "react";

/**
 * Hero scroll-exit token: publishes --hero (0..1) on the hero section as it
 * scrolls out of the viewport, so hero pieces in CSS can lift apart.
 */
export function useHeroExit<T extends HTMLElement = HTMLElement>() {
  const ref = useRef<T>(null);

  useEffect(() => {
    const node = ref.current;
    if (!node) return;
    let frame = 0;
    let last = -1;

    const measure = () => {
      frame = 0;
      const rect = node.getBoundingClientRect();
      const span = Math.max(1, rect.height * 0.8);
      const p = Math.min(1, Math.max(0, -rect.top / span));
      if (Math.abs(p - last) > 0.001) {
        last = p;
        node.style.setProperty("--hero", p.toFixed(3));
      }
    };
    const schedule = () => {
      if (frame) return;
      frame = requestAnimationFrame(measure);
    };

    measure();
    window.addEventListener("scroll", schedule, { passive: true });
    window.addEventListener("resize", schedule, { passive: true });
    return () => {
      window.removeEventListener("scroll", schedule);
      window.removeEventListener("resize", schedule);
      if (frame) cancelAnimationFrame(frame);
    };
  }, []);

  return ref;
}
