import { Users, ShieldCheck, Zap, Send, LayoutGrid, BadgeCheck } from "lucide-react";
import { SearchBar } from "./TopNav";
import { useHeroExit } from "./hero-motion";
import type { LandingData } from "../lib/landing-data";

const TRUST_ICONS = { users: Users, shield: ShieldCheck, zap: Zap } as const;

export function Hero({ data }: { data: LandingData }) {
  const sectionRef = useHeroExit();

  return (
    <section ref={sectionRef} id="top" className="relative mx-auto max-w-7xl scroll-mt-28 px-4 pb-16 pt-24 sm:px-6 lg:pb-24 lg:pt-28" aria-label="معرفی سامانه">
      <div className="hero-grid">
        {/* ---------------------------------------------- copy ---------------------------------------------- */}
        <div className="hero-piece-text order-1 lg:order-1">
          <span className="hero-eyebrow">
            <span className="relative flex size-2">
              <span className="absolute inline-flex size-full animate-ping rounded-full bg-emerald-400 opacity-70" />
              <span className="relative inline-flex size-2 rounded-full bg-emerald-400" />
            </span>
            {data.badge}
          </span>

          <h1 className="hero-title">
            <span className="block">{data.heroTitle.lead}</span>
            {data.heroTitle.gold && <span className="gold block">{data.heroTitle.gold}</span>}
            {data.heroTitle.cyan && <span className="cyan block">{data.heroTitle.cyan}</span>}
            {!data.heroTitle.gold && !data.heroTitle.cyan && <span className="block">{data.heroTitle.cyan || data.heroTitle.gold}</span>}
          </h1>

          <p className="hero-sub">{data.heroSubtitle}</p>
          <p className="hero-text">{data.heroText}</p>

          <div className="mt-7 flex flex-wrap items-center gap-3">
            <a href={data.primaryCta.href} className="btn btn-primary btn-lg gold-sheen">
              <Send className="size-5" />
              {data.primaryCta.label}
            </a>
            <a href={data.secondaryCta.href} className="btn btn-soft btn-lg">
              <LayoutGrid className="size-5" />
              {data.secondaryCta.label}
            </a>
          </div>

          <div className="mt-5 max-w-xl">
            <SearchBar data={data} onSearch={() => undefined} />
          </div>

          <ul className="mt-6 flex flex-wrap gap-x-5 gap-y-2 text-[0.72rem] font-semibold text-faint">
            {data.trust.map((item) => {
              const Icon = TRUST_ICONS[item.icon];
              return (
                <li key={item.text} className="flex items-center gap-1.5">
                  <Icon className="size-4 text-emerald-500" />
                  {item.text}
                </li>
              );
            })}
          </ul>
        </div>

        {/* --------------------------- architectural media --------------------------- */}
        <div className="hero-piece-media order-2 lg:order-2">
          <div className="hero-media">
            <div className="hero-media-glow" />
            <div className="hero-media-frame">
              <img src="/images/hero-building.png" alt="ساختمان دفتر پیشخوان دولت" fetchPriority="high" decoding="async" />
            </div>
            <span className="hero-media-tag">
              <BadgeCheck className="size-4 text-emerald-500" />
              <span className="pulse" />
              دفتر پیشخوان — آمادهٔ ثبت
            </span>
          </div>
        </div>
      </div>
    </section>
  );
}
