import { useRef, type CSSProperties } from "react";
import {
  ArrowLeft, CarFront, FileText, HandCoins, Store, Building2, BadgeCheck, Clock, TrendingUp,
} from "lucide-react";
import { useReveal, useHoverTilt } from "../lib/motion";
import { faNum } from "../lib/landing-data";
import type { LandingData } from "../lib/landing-data";

const ICONS: Record<string, typeof FileText> = {
  "file-text": FileText,
  "hand-coins": HandCoins,
  car: CarFront,
  store: Store,
  building: Building2,
  badge: BadgeCheck,
};

/* ------------------------------ marquee ---------------------------------- */

export function Ticker({ data }: { data: LandingData }) {
  const items = [...data.categories, ...data.categories];
  return (
    <div className="ticker-wrap py-7" aria-hidden="true">
      <div className="ticker-track">
        {items.map((category, index) => {
          const Icon = ICONS[category.icon] ?? FileText;
          return (
            <span key={`${category.id}-${index}`} className="ticker-item">
              <Icon className="size-4" style={{ color: category.gradient[0] }} />
              {category.title}
              <span className="text-faint">· {faNum(category.serviceCount)} خدمت</span>
            </span>
          );
        })}
      </div>
    </div>
  );
}

/* ---------------------------- category rail ------------------------------ */

export function CategoryRail({ data }: { data: LandingData }) {
  const railRef = useRef<HTMLDivElement>(null);
  const reveal = useReveal<HTMLElement>();

  const scroll = (dir: 1 | -1) => railRef.current?.scrollBy({ left: dir * 380, behavior: "smooth" });

  return (
    <section ref={reveal} id="categories" className="mx-auto max-w-7xl scroll-mt-24 px-4 py-6 sm:px-6" aria-label="دسته‌بندی خدمات">
      <div className="mb-6 flex flex-wrap items-end justify-between gap-3" data-reveal>
        <div>
          <h2 className="text-xl font-black text-text sm:text-2xl">دسته‌بندی خدمات</h2>
          <p className="mt-1 text-sm text-muted">دسترسی سریع به پرکاربردترین خدمات دولتی</p>
        </div>
        <div className="flex items-center gap-2">
          <button type="button" className="icon-btn icon-soft" aria-label="دسته‌های قبلی" onClick={() => scroll(1)}>
            <ArrowLeft className="size-4" />
          </button>
          <button type="button" className="icon-btn icon-soft" aria-label="دسته‌های بعدی" onClick={() => scroll(-1)}>
            <ArrowLeft className="size-4 -scale-x-100" />
          </button>
        </div>
      </div>

      <div ref={railRef} className="no-scrollbar -mx-4 flex snap-x snap-mandatory gap-3 overflow-x-auto px-4 pb-3 sm:-mx-6 sm:px-6">
        {data.categories.map((category) => {
          const Icon = ICONS[category.icon] ?? FileText;
          return (
            <a
              key={category.id}
              href="#services"
              data-reveal="zoom"
              className="group w-[8.4rem] shrink-0 snap-start rounded-3xl border border-line bg-ink/60 p-4 text-center backdrop-blur-md transition duration-300 hover:-translate-y-1.5 hover:border-cyan-400/40 hover:shadow-xl hover:shadow-cyan-500/10 sm:w-40"
            >
              <span
                className="mx-auto grid size-16 place-items-center rounded-2xl text-white shadow-lg transition duration-300 group-hover:scale-110"
                style={{ background: `linear-gradient(150deg, ${category.gradient[0]} 0%, ${category.gradient[1]} 100%)`, boxShadow: `0 12px 26px -10px ${category.gradient[0]}66` }}
              >
                <Icon className="size-7" strokeWidth={2} />
              </span>
              <span className="mt-3 block text-[13px] font-extrabold leading-6 text-text">{category.title}</span>
              <span className="mt-1 block text-[10px] font-semibold text-muted">{faNum(category.serviceCount)} خدمت</span>
            </a>
          );
        })}
      </div>
    </section>
  );
}

/* ----------------------------- services grid ---------------------------- */

function ServiceCard({ service, index }: { service: LandingData["popularServices"][number]; index: number }) {
  const tiltRef = useHoverTilt<HTMLElement>(9);
  const Icon = ICONS[service.icon] ?? FileText;
  const category = service.categoryId;
  const catData = [
    { id: "vehicles", gradient: ["#a78bfa", "#7c3aed"] },
    { id: "pension", gradient: ["#f6c453", "#f59e0b"] },
    { id: "housing", gradient: ["#38bdf8", "#1d4ed8"] },
    { id: "business", gradient: ["#34d399", "#059669"] },
    { id: "docs", gradient: ["#22d3ee", "#38bdf8"] },
    { id: "registry", gradient: ["#fb7185", "#be123c"] },
  ].find((c) => c.id === category) ?? { id: "docs", gradient: ["#22d3ee", "#38bdf8"] };

  return (
    <article
      ref={tiltRef}
      data-reveal="zoom"
      className="card-3d h-full"
      style={{ transitionDelay: `${Math.min(index, 6) * 60}ms` } as CSSProperties}
    >
      <div className="svc-card group h-full">
        <div
          className="svc-media"
          style={{ background: `radial-gradient(120% 100% at 30% 10%, ${catData.gradient[0]}30 0%, rgb(10 16 32 / 0.4) 60%), linear-gradient(150deg, rgb(17 27 51), rgb(10 16 32))` }}
        >
          <span
            className="svc-icon"
            style={{ background: `linear-gradient(150deg, ${catData.gradient[0]}, ${catData.gradient[1]})`, boxShadow: `0 16px 34px -12px ${catData.gradient[0]}88` }}
          >
            <Icon className="size-6 text-white" strokeWidth={2.1} />
          </span>
          {service.badge && (
            <span className="absolute right-3 top-3 z-10 inline-flex items-center gap-1 rounded-full bg-emerald-400/15 px-2.5 py-1 text-[10px] font-extrabold text-emerald-300 ring-1 ring-emerald-400/35">
              <TrendingUp className="size-3" />
              {service.badge}
            </span>
          )}
        </div>

        <div className="p-4">
          <h3 className="text-[0.9rem] font-extrabold leading-6 text-text transition group-hover:text-cyan-300">{service.title}</h3>
          <p className="mt-1.5 line-clamp-2 min-h-[2.6rem] text-[0.72rem] leading-6 text-muted">{service.summary}</p>
          <div className="mt-3 flex items-center justify-between border-t border-line pt-3 text-[0.7rem]">
            <span className="font-extrabold text-gold">{service.fee}</span>
            <span className="flex items-center gap-1 text-muted">
              <Clock className="size-3.5" />
              {service.duration}
            </span>
          </div>
        </div>
      </div>
    </article>
  );
}

export function ServicesSection({ data }: { data: LandingData }) {
  const reveal = useReveal<HTMLElement>();

  return (
    <section ref={reveal} id="services" className="mx-auto max-w-7xl scroll-mt-24 px-4 py-14 sm:px-6" aria-label="خدمات پرکاربرد">
      <div className="mb-7 flex flex-wrap items-end justify-between gap-3" data-reveal>
        <div>
          <h2 className="text-2xl font-black text-text sm:text-3xl">خدمات پرکاربرد</h2>
          <p className="mt-2 max-w-2xl text-sm text-muted">
            پرکاربردترین خدمات همین حالا فعالند. هزینه و زمان تقریبی هر خدمت از همان صفحهٔ ثبت درخواست قابل مشاهده است.
          </p>
        </div>
        <a href="#journey" className="btn btn-soft btn-sm" data-reveal="left">
          مشاهدهٔ همهٔ خدمات
          <ArrowLeft className="size-4" />
        </a>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {data.popularServices.map((service, index) => (
          <ServiceCard key={service.id} service={service} index={index} />
        ))}
      </div>
    </section>
  );
}
