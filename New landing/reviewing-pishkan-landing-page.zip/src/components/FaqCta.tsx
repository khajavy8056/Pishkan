import { ChevronDown, HelpCircle, Send, ArrowLeft, ShieldCheck, MapPin, Phone, Mail } from "lucide-react";
import { useReveal } from "../lib/motion";
import type { LandingData } from "../lib/landing-data";

export function FaqSection({ data }: { data: LandingData }) {
  const reveal = useReveal<HTMLElement>();
  return (
    <section ref={reveal} id="faq" className="mx-auto max-w-3xl scroll-mt-24 px-4 py-16 sm:px-6" aria-label="پرسش‌های متداول">
      <div className="mb-8 text-center" data-reveal>
        <span className="inline-flex items-center gap-2 rounded-full border bg-cyan-400/10 px-3 py-1 text-xs font-extrabold text-brand-text border-cyan-400/30">
          <HelpCircle className="size-4" />
          پرسش‌های متداول
        </span>
        <h2 className="mt-3 text-2xl font-black text-text sm:text-3xl">هر آنچه برای ثبت درخواست لازم است بدانید</h2>
      </div>

      <div className="space-y-2.5">
        {data.faq.map((item, index) => (
          <details
            key={item.q}
            className="faq-item"
            data-reveal="left"
            style={{ transitionDelay: `${Math.min(index, 6) * 50}ms` }}
          >
            <summary className="faq-summary">
              <span className="flex items-start gap-2.5">
                <span className="mt-0.5 grid size-6 shrink-0 place-items-center rounded-lg border border-cyan-400/25 bg-cyan-400/12 text-[11px] font-black text-brand-text">
                  {"۰۱۲۳۴۵۶۷۸۹"[index % 10]}
                </span>
                {item.q}
              </span>
              <ChevronDown className="faq-chev size-4.5" />
            </summary>
            <p className="faq-body">{item.a}</p>
          </details>
        ))}
      </div>
    </section>
  );
}

export function CtaSection({ data }: { data: LandingData }) {
  const reveal = useReveal<HTMLElement>();
  return (
    <section ref={reveal} className="mx-auto max-w-7xl px-4 pb-20 sm:px-6" aria-label="دعوت به اقدام نهایی">
      <div
        data-reveal="zoom"
        className="cta-panel px-6 py-12 text-center sm:px-10 sm:py-16"
      >
        <div aria-hidden="true" className="pointer-events-none absolute -top-24 right-1/4 size-72 rounded-full bg-white/10 blur-3xl" />
        <div aria-hidden="true" className="pointer-events-none absolute -bottom-28 left-1/4 size-80 rounded-full bg-emerald-400/20 blur-3xl" />
        <div aria-hidden="true" className="pointer-events-none absolute inset-0 opacity-[0.07]" style={{ backgroundImage: "radial-gradient(circle at 1px 1px, rgb(255 255 255 / 0.7) 1px, transparent 0)", backgroundSize: "26px 26px" }} />

        <div className="relative mx-auto max-w-2xl">
          <h2 className="text-2xl font-black leading-[1.45] text-white sm:text-3xl">{data.cta.title}</h2>
          <p className="mt-3 text-sm leading-7 text-white/80">{data.cta.text}</p>
          <div className="mt-7 flex flex-wrap items-center justify-center gap-3">
            <a href={data.cta.primary.href} className="btn btn-lg gold-sheen rounded-full bg-white px-7 font-black text-brand-700 shadow-xl transition hover:scale-[1.03]">
              <Send className="size-5 -scale-x-100" />
              {data.cta.primary.label}
            </a>
            <a href={data.cta.secondary.href} className="btn btn-lg rounded-full border-2 border-white/30 px-7 font-bold text-white transition hover:bg-white/10">
              {data.cta.secondary.label}
              <ArrowLeft className="size-4" />
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}

export function Footer({ data }: { data: LandingData }) {
  const links = data.footer.links;
  const phoneMatch = data.footer.contact.match(/(۰|[0-9])[۰-۹0-9- ]+?(?=[،، ]|$)/);
  const mailMatch = data.footer.contact.match(/[^\s،]+@[^\s،]+/);

  return (
    <footer className="footer-shell relative overflow-hidden">
      <div className="mx-auto max-w-7xl px-4 pt-12 pb-8 sm:px-6">
        <div className="flex flex-wrap items-start gap-x-10 gap-y-8">
          {/* brand */}
          <div className="max-w-xs">
            <div className="flex items-center gap-3">
              <span className="grid size-11 place-items-center rounded-xl bg-gradient-to-br from-cyan-500 to-brand-600 shadow-lg shadow-cyan-500/25">
                <ShieldCheck className="size-6 text-white" />
              </span>
              <span className="leading-tight">
                <span className="block text-base font-black text-shell-text">{data.brand.name}</span>
                <span className="block text-[0.68rem] font-medium text-shell-muted">{data.brand.tagline}</span>
              </span>
            </div>
            <p className="mt-3 text-[0.78rem] leading-6 text-shell-muted">{data.footer.tagline}</p>
          </div>

          {/* quick links */}
          <nav aria-label="پیوندهای فوتر" className="flex flex-wrap items-center gap-x-4 gap-y-2 text-sm">
            {links.map((link) => (
              <a key={link.href} href={link.href} className="footer-link">
                {link.label}
              </a>
            ))}
          </nav>

          {/* contact */}
          <div className="ms-auto space-y-2 text-[0.78rem] text-shell-muted">
            {mailMatch && (
              <a href={`mailto:${mailMatch[0]}`} className="flex items-center gap-2 transition hover:text-shell-text">
                <Mail className="size-4 text-cyan-500" />
                <span dir="ltr">{mailMatch[0]}</span>
              </a>
            )}
            {phoneMatch && (
              <a href={`tel:${phoneMatch[0].trim()}`} className="flex items-center gap-2 transition hover:text-shell-text">
                <Phone className="size-4 text-cyan-500" />
                <span dir="ltr">{phoneMatch[0].trim()}</span>
              </a>
            )}
            <p className="flex items-center gap-2">
              <MapPin className="size-4 text-cyan-500" />
              <span>تهران · دفتر پیشخوان دولت</span>
            </p>
          </div>
        </div>

        <div className="mt-9 border-t border-line pt-5 text-center text-[0.7rem] font-semibold text-shell-muted">
          © {new Date().getFullYear()} تک پیشخوان · {data.brand.nameEn} · تمام حقوق محفوظ است
        </div>
      </div>
    </footer>
  );
}
