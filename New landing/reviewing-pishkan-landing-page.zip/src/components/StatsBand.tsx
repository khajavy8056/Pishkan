import { useCountUp, useReveal } from "../lib/motion";
import { faNum } from "../lib/landing-data";
import type { LandingData } from "../lib/landing-data";

function StatTile({ label, value, suffix, caption, index }: { label: string; value: number; suffix: string; caption: string; index: number }) {
  const { ref, value: shown } = useCountUp(value, 1400);
  return (
    <div className="stat-tile" data-reveal style={{ transitionDelay: `${index * 80}ms` }}>
      <div className="stat-figure">
        <span ref={ref}>{faNum(shown)}</span>
        <span className="text-cyan-300">{suffix}</span>
      </div>
      <p className="stat-label">{label}</p>
      <p className="text-[0.68rem] font-semibold text-faint">{caption}</p>
    </div>
  );
}

export function StatsBand({ data }: { data: LandingData }) {
  const reveal = useReveal<HTMLElement>();
  return (
    <section ref={reveal} className="mx-auto max-w-7xl px-4 py-6 sm:px-6" aria-label="آمار سامانه">
      <div className="stat-grid">
        {data.stats.map((stat, index) => (
          <StatTile key={stat.label} label={stat.label} value={stat.value} suffix={stat.suffix} caption={stat.caption} index={index} />
        ))}
      </div>
    </section>
  );
}
