import { useEffect, useRef, useState } from "react";
import { Menu, X, ShieldCheck, Search, ArrowLeft, LogIn, Sun, Moon, Monitor } from "lucide-react";
import { useTheme, type ThemeMode } from "../lib/theme";
import type { LandingData } from "../lib/landing-data";

function ThemeToggle() {
  const { mode, setMode } = useTheme();
  const options: { value: ThemeMode; icon: typeof Sun; rtl: string; title: string }[] = [
    { value: "light", icon: Sun, rtl: "روشن", title: "حالت روشن" },
    { value: "dark", icon: Moon, rtl: "تاریک", title: "حالت تاریک" },
    { value: "system", icon: Monitor, rtl: "سیستم", title: "هماهنگ با سیستم" },
  ];
  return (
    <div role="group" aria-label="حالت نمایشی" className="hidden items-center gap-0.5 rounded-full border border-line bg-ink/60 p-1 backdrop-blur-xl sm:flex">
      {options.map((option) => {
        const Icon = option.icon;
        const active = mode === option.value;
        return (
          <button
            key={option.value}
            type="button"
            title={option.title}
            aria-label={option.title}
            aria-pressed={active}
            onClick={() => setMode(option.value)}
            className={`relative grid size-8 place-items-center rounded-full transition-all duration-200 ${active ? "text-cyan-600 shadow-[inset_0_0_0_1px_rgb(34_211_238/0.4)]" : "text-muted hover:text-text"}`}
          >
            <Icon className="size-4" strokeWidth={2.2} />
            {active && <span className="absolute inset-0 rounded-full bg-cyan-400/12" aria-hidden="true" />}
          </button>
        );
      })}
    </div>
  );
}

export function TopNav({ data, progress }: { data: LandingData; progress: number }) {
  const [open, setOpen] = useState(false);
  const { mode, toggle } = useTheme();
  const links = [
    { label: "خدمات", href: "#services" },
    { label: "مسیر ثبت", href: "#journey" },
    { label: "اپلیکیشن", href: "#app" },
    { label: "پرسش‌ها", href: "#faq" },
  ];

  return (
    <>
      <a href="#top" className="fixed inset-x-4 top-0 z-[75] h-[3px]" aria-hidden="true">
        <div
          className="absolute inset-y-0 right-0 bg-gradient-to-l from-emerald-400 via-cyan-400 to-violet-400"
          style={{ width: `${progress}%`, boxShadow: "0 0 18px rgb(56 189 248 / 0.45)" }}
        />
      </a>

      <header className="glass fixed top-3 inset-x-3 z-[60] mx-auto max-w-6xl rounded-2xl lg:top-4 lg:inset-x-6 lg:max-w-7xl">
        <div className="flex h-[58px] items-center gap-2.5 px-3.5 sm:gap-3 sm:px-4">
          <a href="#top" className="flex min-w-0 shrink-0 items-center gap-2.5 rounded-xl" aria-label="صفحه فرود">
            <span className="grid size-9 shrink-0 place-items-center rounded-xl bg-gradient-to-br from-cyan-400 to-brand-600 shadow-lg shadow-cyan-500/30">
              <ShieldCheck className="size-5 text-white" strokeWidth={2.4} />
            </span>
            <span className="min-w-0 leading-tight">
              <span className="block truncate text-[0.92rem] font-black text-text">{data.brand.name}</span>
              <span className="hidden truncate text-[0.6rem] font-medium text-muted sm:block">{data.brand.tagline}</span>
            </span>
          </a>

          <nav className="mx-auto hidden items-center gap-1 lg:flex" aria-label="ناوبری اصلی">
            {links.map((link) => (
              <a
                key={link.href}
                href={link.href}
                className="rounded-full px-4 py-2 text-[0.82rem] font-semibold text-muted transition-colors hover:bg-white/8 hover:text-text"
              >
                {link.label}
              </a>
            ))}
          </nav>

          <div className="ms-auto flex shrink-0 items-center gap-1.5 sm:gap-2">
            <ThemeToggle />
            <a href="/login" className="btn btn-primary btn-sm" aria-label="ورود">
              <LogIn className="size-4" />
              <span className="sm:hidden">ورود</span>
              <span className="hidden sm:inline">ورود / ثبت‌نام</span>
            </a>
            <button
              type="button"
              className="grid size-10 place-items-center rounded-xl text-muted ring-1 ring-line transition hover:text-text lg:hidden"
              onClick={() => setOpen((v) => !v)}
              aria-expanded={open}
              aria-label="منو"
            >
              {open ? <X className="size-5" /> : <Menu className="size-5" />}
            </button>
          </div>
        </div>

        {open && (
          <div className="animate-pop border-t border-line bg-ink/92 px-4 py-3 backdrop-blur-xl lg:hidden">
            <nav className="flex flex-col gap-1" aria-label="ناوبری موبایل">
              {links.map((link) => (
                <a
                  key={link.href}
                  href={link.href}
                  onClick={() => setOpen(false)}
                  className="rounded-xl px-3 py-2.5 text-sm font-semibold text-text transition hover:bg-white/6"
                >
                  {link.label}
                </a>
              ))}
              <button
                type="button"
                onClick={() => toggle()}
                className="mt-2 flex items-center justify-center gap-2 rounded-xl bg-white/6 px-3 py-2.5 text-sm font-semibold text-text ring-1 ring-line transition hover:bg-white/10"
              >
                {mode === "dark" ? (<><Sun className="size-4" /> حالت روشن</>) : (<><Moon className="size-4" /> حالت تاریک</>)}
              </button>
              <a href="/login" className="btn btn-primary mt-1.5 justify-center">
                <LogIn className="size-4" /> ورود / ثبت‌نام
              </a>
            </nav>
          </div>
        )}
      </header>
    </>
  );
}

export function SearchBar({ data, onSearch }: { data: LandingData; onSearch: (q: string) => void }) {
  const [query, setQuery] = useState("");
  const [results, setResults] = useState<LandingData["popularServices"]>([]);
  const ref = useRef<HTMLDivElement>(null);
  const show = query.trim().length >= 2;

  useEffect(() => {
    if (!show) { setResults([]); return; }
    const timer = setTimeout(() => {
      const q = query.toLowerCase();
      setResults(
        data.popularServices.filter(
          (s) => s.title.toLowerCase().includes(q) || s.summary.toLowerCase().includes(q) || s.slug.toLowerCase().includes(q),
        ),
      );
    }, 220);
    return () => clearTimeout(timer);
  }, [query, show, data]);

  useEffect(() => {
    if (!show) return;
    const close = (event: PointerEvent) => {
      if (ref.current?.contains(event.target as Node)) return;
      setQuery("");
      setResults([]);
    };
    document.addEventListener("pointerdown", close, true);
    return () => document.removeEventListener("pointerdown", close, true);
  }, [show]);

  return (
    <div className="relative w-full" ref={ref}>
      <form
        onSubmit={(e) => { e.preventDefault(); onSearch(query); }}
        className="hero-search"
        role="search"
      >
        <Search className="size-5 shrink-0 text-muted" aria-hidden="true" />
        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Escape") setQuery("");
          }}
          placeholder={data.searchPlaceholder}
          aria-label="جست‌وجوی خدمات"
          aria-expanded={show && results.length > 0}
          aria-controls="hero-search-results"
          autoComplete="off"
          className="min-w-0 flex-1 bg-transparent py-2 text-sm text-text outline-none placeholder:text-faint"
        />
        <button type="submit" className="btn btn-primary btn-sm rounded-full">جست‌وجو</button>
      </form>

      {show && results.length > 0 && (
        <div
          role="listbox"
          id="hero-search-results"
          aria-label="نتایج جست‌وجو"
          className="glass animate-pop absolute inset-x-0 top-full z-30 mt-2 overflow-hidden rounded-2xl shadow-2xl"
        >
          {results.map((item) => (
            <a
              key={item.id}
              href="#services"
              role="option"
              aria-selected={false}
              onClick={() => setQuery("")}
              className="flex items-center justify-between gap-3 border-b border-line px-4 py-3 text-sm transition last:border-0 hover:bg-cyan-400/8 focus-visible:bg-cyan-400/8"
            >
              <span className="font-semibold text-text">{item.title}</span>
              <span className="flex items-center gap-2 text-xs text-muted">
                <span className="rounded-full border border-line bg-surface-2 px-2.5 py-0.5">{item.duration}</span>
                <ArrowLeft className="size-4" aria-hidden="true" />
              </span>
            </a>
          ))}
        </div>
      )}
    </div>
  );
}
