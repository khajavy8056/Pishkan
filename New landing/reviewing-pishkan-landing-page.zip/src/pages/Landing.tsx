import { useEffect, useState } from "react";
import { DEFAULT_LANDING, mergeBootstrap, type LandingData } from "../lib/landing-data";
import { TopNav } from "../components/TopNav";
import { Hero } from "../components/Hero";
import { Ticker, CategoryRail, ServicesSection } from "../components/Services";
import { Journey } from "../components/Journey";
import { StatsBand } from "../components/StatsBand";
import { AppSection } from "../components/AppSection";
import { FaqSection, CtaSection, Footer } from "../components/FaqCta";

/* ------------------------- scroll progress ------------------------- */

function useScrollProgress() {
  const [progress, setProgress] = useState(0);
  useEffect(() => {
    let frame = 0;
    const measure = () => {
      frame = 0;
      const el = document.documentElement;
      const total = el.scrollHeight - window.innerHeight;
      const p = total <= 0 ? 0 : Math.min(100, Math.max(0, (window.scrollY / total) * 100));
      setProgress((prev) => (Math.abs(prev - p) < 0.3 ? prev : p));
    };
    const schedule = () => {
      if (frame) return;
      frame = requestAnimationFrame(measure);
    };
    measure();
    window.addEventListener("scroll", schedule, { passive: true });
    window.addEventListener("resize", schedule, { passive: true });
    return () => {
      window.removeEventListener("scroll", schedule);
      window.removeEventListener("resize", schedule);
      if (frame) cancelAnimationFrame(frame);
    };
  }, []);
  return progress;
}

/* ------------------------- bootstrap loading ------------------------- */

function useLandingData(): LandingData {
  const [data, setData] = useState<LandingData>(DEFAULT_LANDING);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const res = await fetch("/api/public/bootstrap", { credentials: "same-origin" });
        if (!res.ok) return;
        const json = await res.json();
        if (!cancelled && json?.data) setData(mergeBootstrap(DEFAULT_LANDING, json));
      } catch {
        // standalone: defaults stay in place
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  return data;
}

/* ------------------------- composition ------------------------- */

export default function Landing() {
  const data = useLandingData();
  const progress = useScrollProgress();

  return (
    <div className="landing-shell" id="landing-root">
      <div className="aurora" aria-hidden="true">
        <div className="aurora-blob a1" />
        <div className="aurora-blob a2" />
        <div className="aurora-blob a3" />
      </div>
      <div className="dot-grid" aria-hidden="true" />
      <div className="grain" aria-hidden="true" />

      <TopNav data={data} progress={progress} />

      <main>
        <Hero data={data} />
        <Ticker data={data} />
        <CategoryRail data={data} />
        <ServicesSection data={data} />
        <StatsBand data={data} />
        <Journey data={data} />
        <AppSection data={data} />
        <FaqSection data={data} />
        <CtaSection data={data} />
      </main>

      <Footer data={data} />
    </div>
  );
}
