import { useSyncExternalStore } from "react";

/**
 * Light / dark / system theme.
 *
 * The store is a standalone module (like the repo's version): no provider is
 * required, and it works for both client and SSR. The dark class lives on the
 * <html> element so a flash-free bootstrap script can set it before paint.
 *
 *   light  | 'dark' — explicit choice, persisted
 *   system — follows the OS preference, nothing persisted
 */

export type ThemeMode = "light" | "dark" | "system";
export type ResolvedTheme = "light" | "dark";

const KEY = "pishkan.theme";

function storedMode(): ThemeMode {
  if (typeof window === "undefined") return "system";
  try {
    const raw = window.localStorage.getItem(KEY);
    return raw === "light" || raw === "dark" ? raw : "system";
  } catch {
    return "system";
  }
}

let currentMode: ThemeMode = storedMode();
const listeners = new Set<() => void>();

function applyTheme() {
  const resolved =
    currentMode === "system"
      ? window.matchMedia?.("(prefers-color-scheme: dark)").matches
        ? "dark"
        : "light"
      : currentMode;
  const root = document.documentElement;
  root.classList.toggle("dark", resolved === "dark");
  root.setAttribute("data-theme", resolved);
  root.style.colorScheme = resolved;
  const meta = document.querySelector('meta[name="theme-color"]');
  if (meta) meta.setAttribute("content", resolved === "dark" ? "#04070f" : "#f2f6fd");
}

// Start from the stored/system preference on first client tick
if (typeof window !== "undefined") {
  currentMode = storedMode();
  applyTheme();
  window.matchMedia?.("(prefers-color-scheme: dark)").addEventListener("change", () => {
    if (currentMode === "system") {
      applyTheme();
      emit();
    }
  });
  window.addEventListener("storage", (event) => {
    if (event.key === KEY) {
      currentMode = storedMode();
      applyTheme();
      emit();
    }
  });
}

function emit() {
  listeners.forEach((listener) => listener());
}

export function getTheme() {
  const resolved =
    currentMode === "system"
      ? window.matchMedia?.("(prefers-color-scheme: dark)").matches
        ? "dark"
        : "light"
      : currentMode;
  return { mode: currentMode, resolved };
}

export function setThemeMode(mode: ThemeMode) {
  currentMode = mode;
  try {
    if (mode === "system") window.localStorage.removeItem(KEY);
    else window.localStorage.setItem(KEY, mode);
  } catch { /* private mode */ }
  applyTheme();
  emit();
}

export function toggleTheme() {
  const { resolved } = getTheme();
  setThemeMode(resolved === "dark" ? "light" : "dark");
}

export function useTheme() {
  const snapshot = useSyncExternalStore(
    (callback) => {
      listeners.add(callback);
      return () => listeners.delete(callback);
    },
    () => `${currentMode}:${document.documentElement.getAttribute("data-theme") ?? "system"}`,
  );
  const { mode, resolved } = getTheme();
  return { mode, resolved, setMode: setThemeMode, toggle: toggleTheme, snapshot };
}

/** Tiny bootstrap snippet inlined in index.html — must run before paint. */
export const THEME_BOOTSTRAP_SCRIPT = `
(function(){try{
  var stored = localStorage.getItem('pishkan.theme');
  var mode = stored === 'light' || stored === 'dark' ? stored : 'system';
  var resolved = mode === 'system'
    ? (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light')
    : mode;
  var root = document.documentElement;
  root.classList.toggle('dark', resolved === 'dark');
  root.setAttribute('data-theme', resolved);
  root.style.colorScheme = resolved;
}catch(e){}})();
`;
