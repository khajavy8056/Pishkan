import { useEffect, useRef, useState, type RefObject } from "react";

/** True when the user asked the OS to reduce motion. */
export function usePrefersReducedMotion(): boolean {
  const [reduced, setReduced] = useState(() => {
    if (typeof window === "undefined" || typeof window.matchMedia !== "function") return false;
    return window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  });
  useEffect(() => {
    if (typeof window.matchMedia !== "function") return;
    const query = window.matchMedia("(prefers-reduced-motion: reduce)");
    const onChange = () => setReduced(query.matches);
    query.addEventListener("change", onChange);
    return () => query.removeEventListener("change", onChange);
  }, []);
  return reduced;
}

/**
 * Scroll reveal with a fail-open pattern, copied from the original landing page:
 * the hidden start state is scoped to `.reveal-armed`, a class added to the
 * container before first paint. If JS never runs or the observer never fires,
 * the content stays visible instead of vanishing.
 */
export function useReveal<T extends HTMLElement = HTMLElement>(options: {
  threshold?: number;
  observe?: RefObject<T | null>;
  stagger?: number;
} = {}): RefObject<T | null> {
  const ownRef = useRef<T>(null);
  const { threshold = 0.12, observe, stagger = 70 } = options;
  const ref = observe ?? ownRef;

  useEffect(() => {
    const node = ref.current;
    if (!node) return;
    // Add before paint so the hidden start state can never be painted by accident.
    node.classList.add("reveal-armed");

    const reduced =
      typeof window.matchMedia === "function" &&
      window.matchMedia("(prefers-reduced-motion: reduce)").matches;

    if (reduced || typeof IntersectionObserver !== "function") {
      node.querySelectorAll<HTMLElement>("[data-reveal]").forEach((el) => el.classList.add("is-in"));
      return;
    }

    const seen = new WeakSet<Element>();
    const show = (el: HTMLElement) => {
      if (seen.has(el)) return;
      seen.add(el);
      el.classList.add("is-in");
    };

    const inScroller = (el: Element): Element | null => {
      let parent = el.parentElement;
      while (parent && parent !== node) {
        const style = getComputedStyle(parent);
        if (/(auto|scroll|overlay)/.test(style.overflow + " " + style.overflowX + " " + style.overflowY)) {
          return parent;
        }
        parent = parent.parentElement;
      }
      return null;
    };

    const observer = new IntersectionObserver(
      (entries) => {
        for (const entry of entries) {
          if (!entry.isIntersecting) continue;
          const el = entry.target as HTMLElement;
          // If an element is inside an internal scroller (the category rail),
          // its own visibility is dictated by that scroller; mark it visible
          // anyway because it will be scrolled through by hand.
          if (inScroller(el)) show(el);
          else show(el);
        }
      },
      { threshold },
    );

    const scan = () => {
      const els = node.querySelectorAll<HTMLElement>("[data-reveal]:not(.is-in)");
      els.forEach((el, i) => {
        el.style.transitionDelay = `${Math.min(i, 6) * stagger}ms`;
        observer.observe(el);
      });
    };

    scan();
    const mutation = new MutationObserver(scan);
    mutation.observe(node, { childList: true, subtree: true });

    return () => {
      mutation.disconnect();
      observer.disconnect();
      node.classList.remove("reveal-armed");
    };
  }, [ref, threshold, stagger]);

  return ref;
}

/** Counts a number up when it first enters the viewport. */
export function useCountUp(target: number, duration = 1300): { ref: RefObject<HTMLSpanElement | null>; value: number } {
  const ref = useRef<HTMLSpanElement>(null);
  const reduced = usePrefersReducedMotion();
  const [value, setValue] = useState(reduced ? target : 0);

  useEffect(() => {
    if (reduced) { setValue(target); return; }
    const node = ref.current;
    if (!node || typeof IntersectionObserver !== "function") { setValue(target); return; }
    let frame = 0;
    let observer: IntersectionObserver | null = null;

    const run = () => {
      const started = performance.now();
      const step = (now: number) => {
        const t = Math.min(1, (now - started) / duration);
        const eased = t === 1 ? 1 : 1 - Math.pow(2, -10 * t);
        setValue(Math.round(target * eased));
        if (t < 1) frame = requestAnimationFrame(step);
      };
      frame = requestAnimationFrame(step);
    };

    const rect = node.getBoundingClientRect();
    if (rect.top < window.innerHeight && rect.bottom > 0) {
      run();
    } else {
      observer = new IntersectionObserver(
        (entries) => {
          if (!entries[0]?.isIntersecting) return;
          observer?.disconnect();
          run();
        },
        { threshold: 0.4 },
      );
      observer.observe(node);
    }

    return () => {
      observer?.disconnect();
      if (frame) cancelAnimationFrame(frame);
    };
  }, [target, duration, reduced]);

  return { ref, value };
}

/** Reads a viewport-driven token on a node, written as CSS custom properties. */
export function useScrollToken<T extends HTMLElement>(property: string, options: { start?: number; end?: number } = {}) {
  const ref = useRef<T>(null);
  const { start = 0, end = 1 } = options;

  useEffect(() => {
    const node = ref.current;
    if (!node) return;
    let frame = 0;
    let last = -1;
    const measure = () => {
      frame = 0;
      const rect = node.getBoundingClientRect();
      const viewport = window.innerHeight || 1;
      const span = viewport + rect.height;
      const travelled = viewport - rect.top;
      let p = travelled / span;
      p = (p - start) / Math.max(0.0001, end - start);
      p = Math.min(1, Math.max(0, p));
      if (Math.abs(p - last) > 0.0015) {
        last = p;
        node.style.setProperty(property, p.toFixed(4));
      }
    };
    const schedule = () => {
      if (frame) return;
      frame = requestAnimationFrame(measure);
    };
    measure();
    window.addEventListener("scroll", schedule, { passive: true });
    window.addEventListener("resize", schedule, { passive: true });
    return () => {
      window.removeEventListener("scroll", schedule);
      window.removeEventListener("resize", schedule);
      if (frame) cancelAnimationFrame(frame);
    };
  }, [property, start, end]);

  return ref;
}

/** Keeps a small JS-side scroll value (0..1) for a pinned track. */
export function usePinnedProgress<T extends HTMLElement = HTMLElement>(enabled = true) {
  const ref = useRef<T | null>(null);
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    if (!enabled) return;
    const node = ref.current;
    if (!node) return;
    let frame = 0;
    const read = () => {
      frame = 0;
      const rect = node.getBoundingClientRect();
      const track = node.offsetHeight - window.innerHeight;
      if (track <= 0) return;
      const p = Math.min(1, Math.max(0, -rect.top / track));
      node.style.setProperty("--j", p.toFixed(4));
      setProgress((prev) => (Math.abs(prev - p) < 0.02 ? prev : p));
    };
    const schedule = () => {
      if (!frame) frame = requestAnimationFrame(read);
    };
    read();
    window.addEventListener("scroll", schedule, { passive: true });
    window.addEventListener("resize", schedule, { passive: true });
    return () => {
      window.removeEventListener("scroll", schedule);
      window.removeEventListener("resize", schedule);
      if (frame) cancelAnimationFrame(frame);
    };
  }, [enabled]);

  return { ref, progress };
}

/** Hover tilt for 3D cards. Touch-inert. */
export function useHoverTilt<T extends HTMLElement>(max = 9) {
  const ref = useRef<T>(null);
  useEffect(() => {
    const node = ref.current;
    if (!node) return;
    if (typeof window.matchMedia === "function" && !window.matchMedia("(hover: hover) and (pointer: fine)").matches) return;
    if (typeof window.matchMedia === "function" && window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;

    let frame = 0;
    const apply = (clientX: number, clientY: number) => {
      const rect = node.getBoundingClientRect();
      const px = (clientX - rect.left) / rect.width - 0.5;
      const py = (clientY - rect.top) / rect.height - 0.5;
      node.style.transform = `perspective(1000px) rotateX(${(-py * max).toFixed(2)}deg) rotateY(${(px * max).toFixed(2)}deg) translateZ(6px)`;
    };
    const reset = () => { node.style.transform = ""; };
    const onMove = (event: PointerEvent) => {
      if (frame) return;
      frame = requestAnimationFrame(() => {
        frame = 0;
        apply(event.clientX, event.clientY);
      });
    };

    node.addEventListener("pointermove", onMove);
    node.addEventListener("pointerleave", reset);
    return () => {
      node.removeEventListener("pointermove", onMove);
      node.removeEventListener("pointerleave", reset);
      if (frame) cancelAnimationFrame(frame);
    };
  }, [max]);
  return ref;
}

/** Mounted outside StrictMode double-effects: cleanup + guards. */
export function useVisibilityPause<T extends HTMLElement>() {
  const ref = useRef<T>(null);
  const [visible, setVisible] = useState(true);
  useEffect(() => {
    const node = ref.current;
    if (!node || typeof IntersectionObserver !== "function") return;
    const observer = new IntersectionObserver(([entry]) => setVisible(entry.isIntersecting), {
      rootMargin: "140px",
    });
    observer.observe(node);
    return () => observer.disconnect();
  }, []);
  return { ref, visible };
}
