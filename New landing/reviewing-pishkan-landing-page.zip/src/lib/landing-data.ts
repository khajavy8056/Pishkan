/**
 * Landing page data — the contract between the landing page and the backend.
 *
 * Same shape as the real /api/public/bootstrap payload, so this page can be
 * rendered end-to-end against the real API once the app is wired up. Standalone,
 * everything falls back to these defaults so the page is never blank.
 */

export interface LandingCategory {
  id: string;
  slug: string;
  title: string;
  serviceCount: number;
  /** gradientStops used for the tile background */
  gradient: [string, string];
  icon: string;
}

export interface LandingService {
  id: string;
  slug: string;
  title: string;
  summary: string;
  fee: string;
  duration: string;
  categoryId: string;
  icon: string;
  isPopular?: boolean;
  badge?: string;
}

export interface LandingStep {
  id: string;
  title: string;
  body: string;
  tag: string;
  glyph: "form" | "dossier" | "upload" | "expert" | "seal";
}

export interface LandingStat { label: string; value: number; suffix: string; caption: string }

export interface LandingFaq { q: string; a: string }

export interface LandingData {
  brand: { name: string; shortName: string; nameEn: string; tagline: string };
  badge: string;
  heroTitle: { lead: string; gold: string; cyan: string };
  heroSubtitle: string;
  heroText: string;
  primaryCta: { label: string; href: string };
  secondaryCta: { label: string; href: string };
  searchPlaceholder: string;
  trust: { icon: "users" | "shield" | "zap"; text: string }[];
  categories: LandingCategory[];
  popularServices: LandingService[];
  journeyTitle: string;
  journeySubtitle: string;
  journeySteps: LandingStep[];
  stats: LandingStat[];
  app: { title: string; text: string; features: { icon: "send" | "bell" | "wallet" | "folder"; text: string }[] };
  faq: LandingFaq[];
  cta: { title: string; text: string; primary: { label: string; href: string }; secondary: { label: string; href: string } };
  footer: { tagline: string; links: { label: string; href: string }[]; contact: string };
}

export const DEFAULT_LANDING: LandingData = {
  brand: {
    name: "تک پیشخوان",
    shortName: "تک پیشخوان",
    nameEn: "Tak-Pishna",
    tagline: "دفتر خدمات دولتی دیجیتال",
  },
  badge: "سامانه رسمی دفتر پیشخوان دولت",
  heroTitle: {
    lead: "یک درخواست،",
    gold: "همه ٔ مراحل آنلاین،",
    cyan: "بدون کاغذبازی.",
  },
  heroSubtitle: "ثبت، پیگیری و تحویل خدمات دولتی — همه در یک سامانه",
  heroText:
    "از انتخاب خدمت و بارگذاری مدارک تا ارجاع کارشناس و تحویل نهایی، مسیر کامل دفتر پیشخوان در چند دقیقه و بدون رفت‌وآمد انجام می‌شود.",
  primaryCta: { label: "ثبت درخواست خدمات", href: "/app/services" },
  secondaryCta: { label: "مشاهده خدمات", href: "#services" },
  searchPlaceholder: "چه خدمتی نیاز دارید؟ مثلاً: تعویض پلاک…",
  trust: [
    { icon: "users", text: "بیش از ۸٬۲۰۰ مشتری ثبت شده" },
    { icon: "shield", text: "مدارک امن و رمزنگاری‌شده" },
    { icon: "zap", text: "ارجاع فوری کارشناس آزاد" },
  ],
  categories: [
    { id: "docs", slug: "documents", title: "اسناد و مدارک", serviceCount: 8, gradient: ["#22d3ee", "#38bdf8"], icon: "file-text" },
    { id: "pension", slug: "pension", title: "بیمه و مالیه", serviceCount: 6, gradient: ["#f6c453", "#f59e0b"], icon: "hand-coins" },
    { id: "vehicles", slug: "vehicles", title: "خودرو و تردد", serviceCount: 5, gradient: ["#a78bfa", "#7c3aed"], icon: "car" },
    { id: "business", slug: "business", title: "تجاری و صنف", serviceCount: 5, gradient: ["#34d399", "#059669"], icon: "store" },
    { id: "housing", slug: "housing", title: "مسکن و شهرسازی", serviceCount: 4, gradient: ["#38bdf8", "#1d4ed8"], icon: "building" },
    { id: "registry", slug: "registry", title: "ثبت‌نام و شناسنامه", serviceCount: 4, gradient: ["#fb7185", "#be123c"], icon: "badge" },
  ],
  popularServices: [
    {
      id: "svc-001",
      slug: "change-plate",
      title: "تعویض پلاک خودرو",
      summary: "تعویض و صدور جدید پلاک وسایل نقلیه بدون حضور فیزیکی",
      fee: "۸۰۰٬۰۰۰ تومان",
      duration: "۲ ساعت",
      categoryId: "vehicles",
      icon: "car",
      isPopular: true,
      badge: "پرکاربرد",
    },
    {
      id: "svc-002",
      slug: "health-insurance",
      title: "سابقهٔ بیمه تأمین اجتماعی",
      summary: "دریافت پروندهٔ بیمه‌پردازی و سابقهٔ پرداختی",
      fee: "۱۲۰٬۰۰۰ تومان",
      duration: "۴ ساعت",
      categoryId: "pension",
      icon: "hand-coins",
      isPopular: true,
    },
    {
      id: "svc-003",
      slug: "property-deed",
      title: "استعلام سند مالکیت",
      summary: "استعلام رسمی سند و ثبت‌های مربوط به ملک",
      fee: "۳۲۰٬۰۰۰ تومان",
      duration: "۱ روز",
      categoryId: "housing",
      icon: "building",
      isPopular: true,
    },
    {
      id: "svc-004",
      slug: "trade-registry",
      title: "ثبت برند تجاری",
      summary: "ثبت برند و علامت تجاری در مرکز ثبت",
      fee: "۱٬۵۰۰٬۰۰۰ تومان",
      duration: "۳ روز",
      categoryId: "business",
      icon: "store",
      isPopular: true,
      badge: "جدید",
    },
  ],
  journeyTitle: "یک کار دولتی، پنج لایه",
  journeySubtitle: "هر درخواستِ شما، یک لایه‌برگ می‌سازد؛ هیچ قدمی گم نمی‌شود و هیچ مدرکی باقی نمی‌ماند.",
  journeySteps: [
    {
      id: "step-1",
      title: "درخواست را ثبت کنید",
      body: "از فهرست خدمات، خدمت مورد نظر را انتخاب می‌کنید. هزینه و زمان تقریبی از همان لحظه نوشته شده است.",
      tag: "لایهٔ ۱ · درخواست",
      glyph: "form",
    },
    {
      id: "step-2",
      title: "پرونده باز می‌شود",
      body: "برای شما یک پروندهٔ دیجیتال باز می‌شود؛ همهٔ مراحل بعدی در همین پرونده ثبت می‌شود.",
      tag: "لایهٔ ۲ · پرونده",
      glyph: "dossier",
    },
    {
      id: "step-3",
      title: "مدارک را بارگذاری کنید",
      body: "مدارک را با دوربین گوشی می‌گیرید یا فایل را می‌کشید؛ نوع و کیفیت هر مدرک همان لحظه بررسی می‌شود.",
      tag: "لایهٔ ۳ · مدارک",
      glyph: "upload",
    },
    {
      id: "step-4",
      title: "کارشناس پرونده را می‌گیرد",
      body: "پروندهٔ کامل به کارشناس آزاد با کمترین بار کاری ارجاع می‌شود؛ نه در صف می‌مانید و نه دست‌به‌دست می‌شود.",
      tag: "لایهٔ ۴ · کارشناس",
      glyph: "expert",
    },
    {
      id: "step-5",
      title: "مُهر تأیید و تحویل",
      body: "نتیجهٔ خدمت را تحویل می‌گیرید و رسید دیجیتال در آرشیو مدارک شما می‌ماند. هر تغییری هم همان لحظه اعلان می‌شود.",
      tag: "لایهٔ ۵ · تحویل",
      glyph: "seal",
    },
  ],
  stats: [
    { label: "خدمت رسمی", value: 42, suffix: "+", caption: "در همهٔ دسته‌ها" },
    { label: "مشتری همراه", value: 8420, suffix: "+", caption: "در سامانه" },
    { label: "پروندهٔ تکمیل‌شده", value: 6280, suffix: "+", caption: "تحویل شده" },
    { label: "ارجاع خودکار", value: 92, suffix: "٪", caption: "سریع‌تر از صف" },
  ],
  app: {
    title: "اپلیکیشن اندروید تک پیشخوان",
    text: "ثبت، پیگیری و پرداخت در هر زمان؛ اپلیکیشن اصلی دفتر پیشخوان — بدون نصب ویندوز با سیستم",
    features: [
      { icon: "send", text: "ثبت و پیگیری از هرجا" },
      { icon: "bell", text: "اعلان لحظه‌ای وضعیت پرونده" },
      { icon: "wallet", text: "کیف پول و پرداخت آنلاین" },
      { icon: "folder", text: "آرشیو همیشگی مدارک" },
    ],
  },
  faq: [
    {
      q: "چگونه درخواست را ثبت کنم؟",
      a: "از صفحهٔ خدمات خدمت مورد نظر را انتخاب می‌کنید؛ فرم پویا ظاهر می‌شود و با تکمیل اطلاعات و بارگذاری مدارک، درخواست ثبت می‌شود. کد پیگیری بلافاصله دریافت می‌کنید.",
    },
    {
      q: "مدارک من چگونه محافظت می‌شوند؟",
      a: "مدارک پس از بارگذاری کیفیت‌محور بررسی و به‌صورت رمزنگاری‌شده آرشیو می‌شوند؛ فقط کارشناس مسئول پرونده به آنها دسترسی دارد.",
    },
    {
      q: "آیا پرداخت آنلاین امن است؟",
      a: "بله؛ پرداخت آنلاین فقط با callback تأییدشدهٔ درگاه پردازش انجام می‌شود تا ثبت پرداختی نامعتبر نباشد.",
    },
    {
      q: "نتایج خدمت را چگونه تحویل می‌گیرم؟",
      a: "بعد از تأیید کارشناس، نتیجه به پنلِ مشتری شما منتقل می‌شود و دکمهٔ دانلود ظاهر می‌شود؛ رسید دیجیتال هم در آرشیو مدارک ذخیره می‌شود.",
    },
    {
      q: "آیا می‌توانم از همان‌جا پیگیری کنم؟",
      a: "بله؛ هر مرحله با اعلان درون‌برنامه‌ای و پیامک و کد پیگیری نمایش داده می‌شود.",
    },
  ],
  cta: {
    title: "همین حالا درخواست را ثبت کنید",
    text: "بدون صف، بدون رفت‌وآمد. مدارک را بارگذاری کنید و پیشرفت پرونده را لحظه‌به‌لحظه ببینید.",
    primary: { label: "ثبت درخواست", href: "/app/services" },
    secondary: { label: "مرور خدمات", href: "#services" },
  },
  footer: {
    tagline: "دفتر خدمات دولتی دیجیتال",
    links: [
      { label: "صفحهٔ فرود", href: "#top" },
      { label: "خدمات", href: "#services" },
      { label: "مسیر ثبت درخواست", href: "#journey" },
      { label: "اپلیکیشن اندروید", href: "#app" },
      { label: "پرسش‌های متداول", href: "#faq" },
    ],
    contact: "info@tak-pishna.ir · ۰۲۱-۴۸۲۲-۰۰۰۰",
  },
};

export function faNum(value: number | string): string {
  if (typeof value === "string" && !/\d/.test(value)) return value;
  if (typeof value === "string" && /^\d{2,}/.test(value)) {
    const trimmed = value.trim();
    return trimmed.replace(/[0-9]/g, (d) => "۰۱۲۳۴۵۶۷۸۹"[Number(d)]);
  }
  return Number(value).toLocaleString("fa-IR");
}

/**
 * Merge a real /api/public/bootstrap payload over the defaults. Values from
 * the API always win; anything missing keeps the default so the page never
 * collapses. This is the seam where the real backend plugs into the design.
 */
export function mergeBootstrap(data: LandingData, bootstrap: unknown): LandingData {
  const json = bootstrap as { data?: { settings?: Record<string, unknown>; categories?: any[]; popularServices?: any[]; stats?: any; assistant?: any } } | undefined;
  const settings = json?.data?.settings;
  if (typeof settings !== "object" || !settings) return data;

  const str = (key: string) => {
    const v = settings[key];
    return typeof v === "string" && v.trim() ? v : undefined;
  };

  const next = { ...data };

  if (str("site.name")) next.brand = { ...next.brand, name: str("site.name")! };
  if (str("site.short_name")) next.brand = { ...next.brand, shortName: str("site.short_name")! };
  if (str("landing.hero_badge")) next.badge = str("landing.hero_badge")!;
  if (str("landing.hero_title")) next.heroTitle = { lead: str("landing.hero_title")!, gold: "", cyan: "" };
  if (str("landing.hero_subtitle")) next.heroSubtitle = str("landing.hero_subtitle")!;
  if (str("landing.hero_text")) next.heroText = str("landing.hero_text")!;
  if (str("landing.primary_cta_label")) next.primaryCta = { ...next.primaryCta, label: str("landing.primary_cta_label")! };
  if (str("landing.primary_cta_link")) next.primaryCta = { ...next.primaryCta, href: str("landing.primary_cta_link")! };
  if (str("landing.secondary_cta_label")) next.secondaryCta = { ...next.secondaryCta, label: str("landing.secondary_cta_label")! };
  if (str("landing.secondary_cta_link")) next.secondaryCta = { ...next.secondaryCta, href: str("landing.secondary_cta_link")! };
  if (str("landing.app_title")) next.app = { ...next.app, title: str("landing.app_title")! };
  if (str("landing.app_text")) next.app = { ...next.app, text: str("landing.app_text")! };

  // FAQ from the office can be a JSON array string
  const faqRaw = str("landing.faq");
  if (faqRaw) {
    try {
      const parsed = JSON.parse(faqRaw);
      if (Array.isArray(parsed) && parsed.length) {
        const faq = parsed
          .filter((item: any) => item?.q && item?.a)
          .map((item: any) => ({ q: String(item.q), a: String(item.a) }))
          .slice(0, 8);
        if (faq.length) next.faq = faq;
      }
    } catch { /* ignore malformed */ }
  }

  // Categories & services from the backend
  const palette: [string, string][] = [
    ["#22d3ee", "#38bdf8"], ["#f6c453", "#f59e0b"], ["#a78bfa", "#7c3aed"],
    ["#34d399", "#059669"], ["#38bdf8", "#1d4ed8"], ["#fb7185", "#be123c"],
  ];
  const apiCategories = json?.data?.categories;
  if (Array.isArray(apiCategories) && apiCategories.length) {
    next.categories = apiCategories.slice(0, 8).map((c: any, i: number) => ({
      id: String(c.id ?? c.slug ?? i),
      slug: String(c.slug ?? i),
      title: String(c.title ?? c.name ?? ""),
      serviceCount: Number(c.serviceCount ?? 0) || 0,
      gradient: [c.color ?? palette[i % palette.length][0], palette[i % palette.length][1]] as [string, string],
      icon: String(c.icon ?? "file-text"),
    })).filter((c: LandingCategory) => c.title);
  }
  const apiPopular = json?.data?.popularServices;
  if (Array.isArray(apiPopular) && apiPopular.length) {
    next.popularServices = apiPopular.slice(0, 8).map((s: any) => {
      const minutes = Number(s.estimatedMinutes ?? 0) || (Number(s.estimatedDays ?? 0) > 0 ? Number(s.estimatedDays) * 1440 : 0);
      const days = Number(s.estimatedDays ?? 0);
      let duration = "—";
      if (minutes > 0 && minutes % 1440 === 0) duration = `${faNum(Math.round(minutes / 1440))} روز`;
      else if (minutes > 0 && minutes % 60 === 0) duration = `${faNum(Math.round(minutes / 60))} ساعت`;
      else if (minutes > 0) duration = `${faNum(Math.round(minutes))} دقیقه`;
      if (days > 0 && !minutes) duration = `${faNum(days)} روز`;
      return {
        id: String(s.id ?? s.slug ?? Math.random()),
        slug: String(s.slug ?? ""),
        title: String(s.title ?? ""),
        summary: String(s.summary ?? s.description ?? "").slice(0, 160),
        fee: faNum(Number(s.finalFee ?? s.baseFee ?? 0)) + " تومان",
        duration,
        categoryId: String(s.categorySlug ?? s.categoryId ?? ""),
        icon: String(s.icon ?? "file-text"),
        isPopular: true,
      } as LandingService;
    }).filter((s: LandingService) => s.title);
  }

  const stats = json?.data?.stats;
  if (stats && typeof stats === "object") {
    const apiStats = [
      { label: "خدمت رسمی", value: Number(stats.services ?? 0) || next.stats[0].value, suffix: "+", caption: "در همهٔ دسته‌ها" },
      { label: "مشتری همراه", value: Number(stats.customers ?? 0) || next.stats[1].value, suffix: "+", caption: "در سامانه" },
      { label: "پروندهٔ تکمیل‌شده", value: Number(stats.completedRequests ?? 0) || next.stats[2].value, suffix: "+", caption: "تحویل شده" },
      next.stats[3],
    ];
    next.stats = apiStats as LandingData["stats"];
  }

  return next;
}
